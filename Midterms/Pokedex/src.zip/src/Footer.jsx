
export default function Footer (){
    return (
        <>
        <footer>
            <hr />
            <p>&copy; {new Date().getFullYear()} Pokédex API Website || Written by: One Lester L. Evangelista & Chrisitan Jay T. Oboob
     </p></footer></>
    )
}