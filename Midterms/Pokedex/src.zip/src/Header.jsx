export default function Header (){
    return (
        <header>
            <h1>Pokédex API Project</h1>
            <hr />
        </header>
    )
}