export default function Footer() {

    return (
        <footer>
            <hr />
            <p>&copy; {new Date().getFullYear()} My GroceryList|| Written by: Christian Oboob</p>
        </footer>
    )
}